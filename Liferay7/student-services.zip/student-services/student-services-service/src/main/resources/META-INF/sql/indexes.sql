create index IX_CC0C83FC on STUDENT_Student (name[$COLUMN_LENGTH:75$]);
create index IX_49B87D17 on STUDENT_Student (uuid_[$COLUMN_LENGTH:75$]);