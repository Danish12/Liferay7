create table STUDENT_Student (
	uuid_ VARCHAR(75) null,
	studentId LONG not null primary key,
	name VARCHAR(75) null,
	sollNumber INTEGER,
	entryDate DATE null
);