package com.liferaytutorials.portlet.constants;

public class PortletKeys {

	public static final String NAME = "MultipleMVCRenderCommand";
}
