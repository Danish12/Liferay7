package com.liferaytutorials.portlet.constant;

public class StudentPortletKeys {

	public static final String PORTLET_NAME = "Student_Portlet";	
}
